<?php


include "connect1.php";


$username=$_POST['Username'];
$password=$_POST['Password'];

if($username && $password){
  $sql="Select * from login WHERE Username='$username' and Password='$password'";
  $rs=mysqli_query($con,$sql);
  $row=mysqli_fetch_array($rs);



  if($row){
    session_start();
    $_SESSION['Username']=$username;
    $URL="index1.php";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
    echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
  }
   else{
    $URL="signup.php";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
    echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
    alert("Incorrect Username or Password");
  }
}
else{
  alert("All Fields Required");
}
?>
