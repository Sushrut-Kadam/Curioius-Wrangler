
<html>
<head>




<?php
include("connect.php");

$sql_points = "Select points1 FROM points";
$sql_data = mysqli_query($db,$sql_points) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $points=$row['points1'];
}



?>

<style>
.topright span{
  display: inline-block;
  position: absolute;
  top: 8px;
  right: 16px;
  font-size: 18px;
}
</style>

<p class="topright">
  <span><?php echo"Points: $points" ?></span>
</p>

</head>
</html>
