<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>

<font color="white">
<body id="banner_image24">


  <h1><center>BrainStorm</center></h1>

  <head>
        <title>METASTORM</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="Styling.css">

        <style>
            h2{
                color: white;
            }



            .panel{
                margin-top: 30px;
                alignment-adjust: middle;
            }
        </style>
</head>

<body id="banner_image24">
    <div class="container">
        <div class="row">
            <h2>Description:</h2>
            <h3>Read the following riddle carefully.<br>The answer to the riddle is your flag.</h3>

            <h2>Riddle:</h2>
            <h4>In this distopian world, your resistance group is humanity's last hope. Unfortunately you've all been captured <br>
by the tyrannical rulers and brought to the ancient Colosseum for their deadly entertainment. Before you're <br>
thrown into the dungeon you see many numbered hallways leading outside, but each exit is blocked by an electric <br>
barrier with a combination keypad. You learn that one of you will be allowed to try to escape by passing a challenge <br>
while everyone else will be fed to mutant salamanders the next morning. With her perfect logical reasoning, Zara <br>
is the obvious choice among the three. You hand her a concealed audio transmitter so that the rest of you can <br>
listen along. As Zara is led away, you hear her footsteps echo through one of the hallways, then stop. A voice <br>
announces that she must enter a code consisting of three positive whole numbers in ascending order, so the second <br>
number is greater than or equal to the first and third is greater than or equal to the second. She may ask upto <br>
three clues, but if she makes a wrong guess or says anything else, she'll be thrown back into the dungeon. <br>
For the first clue, the voice says the product of the three number is 36. <br>
When Zara asks for the second clue it tells her the sum of the numbers is the same as the number of the hallway <br>
she entered. There is a long silence, you're sure that Zara remembers the hallway number, but there is no way <br>
for you to know it and she can't say it outloud. <br>
If Zara could enter the passcode at this point, she would, <br>
but instead asks for the third clue, and the voice announces that the largest number appears only once in the <br>
combination. <br>
Moments later, the buzz of the electric barrier stops for a few seconds, and you realise that Zara has escaped. <br>
Unfortunately her transmitter is no longer in range, so that's all the information you get. Can you find the <br>
solution ? <br></h4>
        </div>

        <div>

        </div>

    </div>
    </font>
    <center>
      <font color="white">
  </h3>Enter Flag</h3>
</font>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check15.php" >
     <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x==229)
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>



</body>
</html>
