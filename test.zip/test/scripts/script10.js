function check()
{
var x=document.forms["myform"]["flag"].value;

if (x=="Abc4")
{
  cnt1+=1;
  return true;
}
else
{
  alert('Invalid Flag: '+x);
  return false;
}
}
