<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>


<font color="white">
  <h1><center>Who am I?</center></h1>
<body id="banner_image15">

<center>
  <!-- <body id="banner_image5"> -->
      <div class="container">
          <!-- <div id="banner_content" class="row inner-banner-image"> -->
              <center><h3><strong>Description:</strong></h3></center>
              <center><p>A good interaction is a must for every task to accomplish and so does in a computer. If you don't have it, your system is useless.</p></center>

              <center><h3><strong>Hint :</strong></h3></center>
              <center><p>I am the threshold to the use of a computer, <br> I am its whole and sole facilitator</p>
              <br/>
              <p>Who am I ?</p></center>
              <p>Note: Use small case letters also include whitespace.</p>
          </div>


  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check13.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="operating system")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>



</font>
</body>
</html>
