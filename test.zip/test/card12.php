<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>

<font color="white">
<h1><center>Number System </center></h1>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>






  <title>METASTORM</title>

          <!-- Latest compiled and minified CSS -->
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

          <!-- jQuery library -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

          <!-- Latest compiled and minified JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

          <link rel="stylesheet" href="Styling.css">

          <style>
              h3,h5{
                  color: white;
              }
              p{
                  color: white;
                  font-size: 22px;
              }
              h4{
                color: black;
              }

              .panel{
                  margin-top: 50px;
                  alignment-adjust: middle;
              }
          </style>
  </head>

  <body id="banner_image4">
      <div class="container">
          <div id="banner_content" class="row inner-banner-image">
              <center><h3><strong>Description:</strong></h3></center>
              <center><p>Knowledge of just one number system is not enough.</p></center>

              <center><h3><strong>Hint:</strong></h3></center>
              <center><p>What is the number system on which computer's work ?</p></center>
          </div>

          <div>
              <img src="Media/Bodmas.png">
          </div>
      </div>

    <center>
      <font color="black">
  <h2>Enter Flag</h2>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check12.php" >
   <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x==110100)
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>



</font>
</body>
</html>
