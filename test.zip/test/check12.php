<!DOCTYPE html>
<html>
<?php

session_start();
include("connect1.php");

$sql_cnt12 = "Select cnt12 FROM points where Username='$_SESSION[Username]'";
$sql_data = mysqli_query($con,$sql_cnt12) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $cnt12=$row['cnt12'];
}





if($cnt12 == 0 && $_POST['flag']==110100){
$sql ="UPDATE points SET cnt12 = cnt12+1 where Username='$_SESSION[Username]'";
$sql1 ="UPDATE points SET Current_time1=(SELECT NOW()) where Username='$_SESSION[Username]'";

if(!mysqli_query($con,$sql)){
  echo "Not Inserted";
  echo($_POST['flag']);
}
else{
  echo "Succesfully Inserted cnt1";

}


if(!mysqli_query($con,$sql1)){
  echo "Not Inserted";
}
else{
  echo "Succesfully Inserted time";

}



$URL="insert3.php";
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}
else{
  echo "Already Submitted";
  echo $_POST['flag'];
  $URL="index1.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
  echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

}






?>
</html>
