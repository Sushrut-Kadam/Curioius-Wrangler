<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>


<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>

<font color="white">
<body id="banner_image15">

  <h1><center>Who am I?</center></h1>


<center>
  <body>
    <div class="container">
        <div class="row">
            <h2>Description:</h2>
            <p>These are the names of general computer functionalities and parts. Let's see how good are you at using a computer
                and let's check your awareness. <em>The answer is your flag </em></p>

            <h2>Hint :</h2>
            <p>If you try to shift your level, you skip me kid,<br>but I preserve what you don't need !</p>
            <br/>
            <p>Who am I ?</p>
            <p>Note: Use Capital letters.</p>
        </div>

        <div>

        </div>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check16.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="RECYCLEBIN")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>


</font>
</body>
</html>
