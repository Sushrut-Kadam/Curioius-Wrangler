<!DOCTYPE>
<html oncontextmenu="return false">
<head>
<style > #homelink{margin: 10px;}
</style>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
  </script>
  <!-- <link rel="stylesheet" href="Styling.css"> -->
</head>


<font color="black">
<body id="banner_image7">
  <h1><center>DEBUG IT2!</center></h1>

  <center><h3>Find the Error in the given Program and run the code to Catch the flag.</h3>
    <h3>
      #include bits/stdc++.h<br>
      using namespace std;<br>

      void search(char* pat, char* txt)<br>
      {<br>
      	int M = strlen(pat);<br>
      	int N = strlen(txt);<br>


      	for (int i = 0; i <= N - M; i++) {<br>
      		int j;<br>


      		for (j = 0; j < M; j++)<br>
      			if (txt[i + j] != pat[j])<br>


      		if (j == M)<br>
      			cout << "Pattern found at index "<br>
      				<< i << endl;<br>
      	}<br>
      }<br>


      int main()<br>
      {<br>
      	char txt[] = "AABAACAADAABAAABAA";<br>
      	char pat[] = "AABA";<br>
      	search(pat, txt);<br>
      	return 0;<br>
      }<br>

    </h3>
    <script type="text/javascript" src="scripts/script5.js"></script>


    <script>
      function check()
      {
      var x=document.forms["myform"]["flag"].value;

      if (x==0913)
      {
        cnt1+=1;
        return true;
      }
      else
      {
        alert('Invalid Flag: '+x);
        return false;
      }
      }
      </script>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check5.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>

  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
</center>


<font>
</body>
</html>
