<?php
$user = 'root';
$pass = '';
$db = 'CuriousWrangler';

$con = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");



 ?>
