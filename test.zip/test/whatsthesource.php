
<!DOCTYPE html>
<html dir="ltr" lang="en">
<a href="index1.php"><button id="homelink">Go To Homepage</button></a>

<head>
	<meta charset="utf-8">

	<!-- This site is optimized with the Sprout SEO plugin - https://sprout.barrelstrengthdesign.com/craft-plugins/seo -->
	<title>Good as Gold - Streetwear, Fashion, Shoes &amp; Accessories</title>
	<meta name="description" content="Shop the latest Mens and Women&#039;s Clothes, Shoes and Accessories from over 70 brands at Good as Gold New Zealand and get Free Shipping Worldwide, Down to Earth E">
	<meta name="keywords" content="streetwear,wellington,fashion,tshirt,nike,wallets,sneakers,footwear,watches,accessories,jewellery,outerwear,jackets,nz,new zealand,adidas,shoes,yu mei,veja,mens,womens,champion,dresses,handbags">
	<link rel="canonical" href="https://goodasgoldshop.com/">
	<meta name="geo.region" content="Wellington">
	<meta name="geo.placename" content="Wellington, New Zealand">
	<meta property="og:type" content="website">
	<meta property="og:site_name" content="Good as Gold">
	<meta property="og:url" content="https://goodasgoldshop.com/">
	<meta property="og:title" content="Homepage">
	<meta property="og:description" content="Down to earth exceptional service stocking the best in fashion &amp; streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.">
	<meta property="og:image" content="https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg">
	<meta property="og:image:secure_url" content="https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg">
	<meta property="og:image:width" content="400">
	<meta property="og:image:height" content="400">
	<meta property="og:image:type" content="image/jpeg">
	<meta property="og:locale" content="en_gb">
	<meta name="twitter:card" content="summary">
	<meta name="twitter:url" content="https://goodasgoldshop.com/">
	<meta name="twitter:title" content="Homepage">
	<meta name="twitter:description" content="Down to earth exceptional service stocking the best in fashion &amp; streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.">
	<meta name="twitter:image" content="https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg">

<script type="application/ld+json">
{
    "@context": "http://schema.org/",
    "@type": "Organization",
    "name": "Independent designers, streetwear & fashion - Good As Gold",
    "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
    "url": "https://goodasgoldshop.com",
    "email": "&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#103;&#111;&#111;&#100;&#97;&#115;&#103;&#111;&#108;&#100;&#115;&#104;&#111;&#112;&#46;&#99;&#111;&#109;",
    "image": {
        "@type": "ImageObject",
        "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
        "height": 400,
        "width": 400
    },
    "sameAs": [
        "http://instagram.com/goodasgoldshop",
        "https://www.facebook.com/shopGoodAsGold/",
        "https://soundcloud.com/goodasgoldshop"
    ]
}
</script>

<script type="application/ld+json">
{
    "@context": "http://schema.org/",
    "@type": "Website",
    "name": "Independent designers, streetwear & fashion - Good As Gold",
    "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
    "keywords": "fashion,streetwear,sneakers,menswear,womenswear",
    "url": "https://goodasgoldshop.com",
    "image": {
        "@type": "ImageObject",
        "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
        "height": 400,
        "width": 400
    },
    "author": {
        "@type": "Organization",
        "name": "Independent designers, streetwear & fashion - Good As Gold",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "url": "https://goodasgoldshop.com",
        "email": "&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#103;&#111;&#111;&#100;&#97;&#115;&#103;&#111;&#108;&#100;&#115;&#104;&#111;&#112;&#46;&#99;&#111;&#109;",
        "image": {
            "@type": "ImageObject",
            "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
            "height": 400,
            "width": 400
        },
        "sameAs": [
            "http://instagram.com/goodasgoldshop",
            "https://www.facebook.com/shopGoodAsGold/",
            "https://soundcloud.com/goodasgoldshop"
        ]
    },
    "copyrightHolder": {
        "@type": "Organization",
        "name": "Independent designers, streetwear & fashion - Good As Gold",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "url": "https://goodasgoldshop.com",
        "email": "&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#103;&#111;&#111;&#100;&#97;&#115;&#103;&#111;&#108;&#100;&#115;&#104;&#111;&#112;&#46;&#99;&#111;&#109;",
        "image": {
            "@type": "ImageObject",
            "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
            "height": 400,
            "width": 400
        },
        "sameAs": [
            "http://instagram.com/goodasgoldshop",
            "https://www.facebook.com/shopGoodAsGold/",
            "https://soundcloud.com/goodasgoldshop"
        ]
    },
    "creator": {
        "@type": "Organization",
        "name": "Independent designers, streetwear & fashion - Good As Gold",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "url": "https://goodasgoldshop.com",
        "email": "&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#103;&#111;&#111;&#100;&#97;&#115;&#103;&#111;&#108;&#100;&#115;&#104;&#111;&#112;&#46;&#99;&#111;&#109;",
        "image": {
            "@type": "ImageObject",
            "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
            "height": 400,
            "width": 400
        },
        "sameAs": [
            "http://instagram.com/goodasgoldshop",
            "https://www.facebook.com/shopGoodAsGold/",
            "https://soundcloud.com/goodasgoldshop"
        ]
    },
    "sameAs": [
        "http://instagram.com/goodasgoldshop",
        "https://www.facebook.com/shopGoodAsGold/",
        "https://soundcloud.com/goodasgoldshop"
    ]
}
</script>

<script type="application/ld+json">
{
    "@context": "http://schema.org/",
    "@type": "CreativeWork",
    "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "https://goodasgoldshop.com/"
    },
    "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
    "image": {
        "@type": "ImageObject",
        "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
        "height": 400,
        "width": 400
    },
    "url": "https://goodasgoldshop.com/",
    "headline": "Homepage",
    "dateCreated": "2018-01-19T13:00:00+13:00",
    "dateModified": "2019-09-19T12:00:00+12:00",
    "datePublished": "2018-01-19T13:00:00+13:00",
    "author": {
        "@type": "Person",
        "name": "Homepage",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "image": {
            "@type": "ImageObject",
            "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
            "height": 400,
            "width": 400
        },
        "url": "https://goodasgoldshop.com/"
    },
    "creator": {
        "@type": "Person",
        "name": "Homepage",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "image": {
            "@type": "ImageObject",
            "url": "https://goodasgoldshop.com/images/_400x400_crop_center-center_82/gagwelly01.jpg",
            "height": 400,
            "width": 400
        },
        "url": "https://goodasgoldshop.com/"
    },
    "publisher": {
        "@type": "Organization",
        "name": "Independent designers, streetwear & fashion - Good As Gold",
        "description": "Down to earth exceptional service stocking the best in fashion & streetwear. Free shipping worldwide. Shop the latest collections from over 70 brands.",
        "url": "https://goodasgoldshop.com",
        "email": "&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#103;&#111;&#111;&#100;&#97;&#115;&#103;&#111;&#108;&#100;&#115;&#104;&#111;&#112;&#46;&#99;&#111;&#109;",
        "image": {
            "@type": "ImageObject",
            "url": "https://www.goodasgoldshop.com/images/gagwelly01.jpg",
            "height": 477,
            "width": 635
        },
        "sameAs": [
            "http://instagram.com/goodasgoldshop",
            "https://www.facebook.com/shopGoodAsGold/",
            "https://soundcloud.com/goodasgoldshop"
        ]
    }
}
</script>
		<meta content="width=device-width, user-scalable=no, initial-scale=1, shrink-to-fit=no, ie=edge" http-equiv="x-ua-compatible"
		  name="viewport">
	<meta content="Description of the page less than 150 characters" name="description">
	<link href="/assets/favicons/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180">
	<link href="/assets/favicons/favicon-32x32.png" rel="icon" sizes="32x32" type="image/png">
	<link href="/assets/favicons/favicon-16x16.png" rel="icon" sizes="16x16" type="image/png">
	<link href="/assets/favicons/manifest.json" rel="manifest">
	<link href="/assets/favicons/safari-pinned-tab.svg" rel="mask-icon">
	<meta content="#ffffff" name="theme-color">
	<link href="/css/styles.css" rel="stylesheet">
	<link preload="font" href="/assets/fonts/Graphik-Regular.woff2" as="font">
    				<style>
			:root {
				--main-color: #FFFFFF;
			}
		</style>
		<!-- Google Analytics -->
	<script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-15274813-4', 'auto');
        ga('send', 'pageview');
	</script>
	<!-- End Google Analytics -->
</head>
<!-- Remove class is-announcement to disable top message-->

<body class="is-announcement">
<a href="https://justtheticketnz.com/events/495c4ccd-497f-af67-05a6-68819362932a?fbclid=IwAR0yaosN2Yw0gnCSNXW6asKyKDuvnCBXS_FRYfAhkgLgKGTMRft8p8V1Ff8" class="announcementMarquee-l" style="background-color: #5ef603" >
	<div class="marquee-anno">
		<p data-text="Get your party tickets here">Get your party tickets here</p>
	</div>
</a>
<div class="navigation light-bg" id="sticky">
	<!-- Accordian Navigaiton -->
	<div class="wrapper">
		<div class="menu-container" id="navbrandToggle">
			<a href="/">
				<div class="logo"></div>
			</a>
			<ul>
				<li class="hidden-sm-up">
					<a href="https://shop.goodasgoldshop.com/collections/new-instore">New In</a>
				</li>
				<li>
					<a href="https://shop.goodasgoldshop.com/collections/mens" class="active-link" id="mensToggle">Mens
						<span class="image-block"></span>
					</a>
					<ul class="mobile-panel">
                                                                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-new">New</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens">View All</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/all/mens+mindful">Mindful</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-exclusives">Exclusives</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-sale">Sale</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-footwear">Footwear</a>
								</b>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-footwear" class="is-navHidden">View All</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/last-pairs" class="is-navHidden">Last Pairs</a>
                                							</li>
													                        							                        							                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-tops">Tops</a>
								</b>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-tops" class="is-navHidden">View All</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-t-shirts" class="is-navHidden">T-shirts</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-hoodies-sweatshirts" class="is-navHidden">Crews / Hoods</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-jackets" class="is-navHidden">Jackets</a>
                                							</li>
													                        							                        							                        							                        							                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-bottoms">Bottoms</a>
								</b>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-bottoms" class="is-navHidden">View All</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-pants-chinos" class="is-navHidden">Pants</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-denim" class="is-navHidden">Denim</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-shorts" class="is-navHidden">Shorts</a>
                                							</li>
													                        							                        							                        							                        							                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-accessories">Accessories</a>
								</b>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-accessories" class="is-navHidden">View All</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-bags" class="is-navHidden">Bags</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-watches" class="is-navHidden">Watches</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-socks" class="is-navHidden">Socks</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-hats" class="is-navHidden">Hats &amp; Caps</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-sunglasses" class="is-navHidden">Sunglasses</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-wallets" class="is-navHidden">Wallets</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-belts" class="is-navHidden">Belts</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/cases-sleeves" class="is-navHidden">Cases &amp; Sleeves</a>
                                							</li>
													                        							                        							                        							                        							                        							                        							                        							                        							                        							                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-jewellery">Jewellery</a>
								</b>
                                							</li>
													                        								<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-goods">Goods</a>
								</b>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-goods" class="is-navHidden">View All</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/fragrance" class="is-navHidden">Fragrance</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/magazines-books" class="is-navHidden">Magazines &amp; Books</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-grooming-products" class="is-navHidden">Grooming Products</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-stuff" class="is-navHidden">Stuff</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/knives" class="is-navHidden">Knives</a>
                                									<a href="https://shop.goodasgoldshop.com/collections/mens-gifts" class="is-navHidden">Gifts</a>
                                							</li>
													                        							                        							                        							                        							                        							                        							                        												</ul>
				</li>
				<li>
					<a href="https://shop.goodasgoldshop.com/collections/womens" class="active-link" id="womensToggle">Womens
						<span class="image-block"></span>
					</a>
					<ul class="mobile-panel">
                                                                            							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-new">New</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens">View All</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mindful/womens">Mindful</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-exclusives">Exclusives</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-sale">Sale</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-footwear">Footwear</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-footwear" class="is-navHidden">View All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-sneakers" class="is-navHidden">Sneakers</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-boots-heels-flats" class="is-navHidden">Boots Heels &amp; Flats</a>
																	<a href="https://shop.goodasgoldshop.com/collections/last-pairs-womens" class="is-navHidden">Last Pairs</a>
															</li>
							                                                                                                                                                                                                                                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-tops">Tops</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-tops" class="is-navHidden">View All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-t-shirts" class="is-navHidden">T-shirts</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-shirts" class="is-navHidden">Shirts</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-hoodies-sweatshirts" class="is-navHidden">Sweaters</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-knitwear" class="is-navHidden">Knitwear</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-jackets" class="is-navHidden">Jackets</a>
															</li>
							                                                                                                                                                                                                                                                                                                                                                                            							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-dresses">Dresses</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-bottoms">Bottoms</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-bottoms" class="is-navHidden">View All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-pants" class="is-navHidden">Pants</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-shorts-skirts" class="is-navHidden">Shorts &amp; Skirts</a>
																	<a href="https://shop.goodasgoldshop.com/collections/jumpsuits" class="is-navHidden">Jumpsuits</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-denim" class="is-navHidden">Denim</a>
															</li>
							                                                                                                                                                                                                                                                                                                                        							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-swimwear">Swimwear</a>
								</b>
															</li>
							                                                    							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-accessories">Accessories</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-accessories" class="is-navHidden">Veiw All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-bags" class="is-navHidden">Bags</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-wallets" class="is-navHidden">Wallets</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-socks-and-tights" class="is-navHidden">Socks &amp; Tights</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-watches" class="is-navHidden">Watches</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-sunglasses" class="is-navHidden">Sunglasses</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-hats" class="is-navHidden">Hats &amp; Caps</a>
															</li>
							                                                                                                                                                                                                                                                                                                                                                                                                                                							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-jewellery">Jewellery</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-jewellery" class="is-navHidden">View All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/hair-clips" class="is-navHidden">Hair Clips</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-rings" class="is-navHidden">Rings</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-earrings" class="is-navHidden">Earrings</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-necklaces" class="is-navHidden">Necklaces</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-bracelets" class="is-navHidden">Bracelets</a>
															</li>
							                                                                                                                                                                                                                                                                                                                                                                            							<li class="navParent">
								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-goods">Goods</a>
								</b>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-goods" class="is-navHidden">View All</a>
																	<a href="https://shop.goodasgoldshop.com/collections/fragrance" class="is-navHidden">Fragrance</a>
																	<a href="https://shop.goodasgoldshop.com/collections/womens-stuff" class="is-navHidden">Stuff</a>
															</li>
							                                                                                                                                                                                    					</ul>
				</li>
				<li>
					<a href="/brands" class="active-link is-active" id="brandsToggle">Brands
						<span class="image-block"></span>
					</a>

					<ul class="mobile-panel">
					  					    <li class="navParent">
					      <b>
					        <a href="/brands">All Brands</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/adidas-originals">Adidas Originals</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/baggu">Baggu</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/brain-dead/">Brain Dead</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/champion">Champion</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/fjallraven/">Fjallraven</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/fuct">FUCT</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/hansel-from-basel/">Hansel from Basel</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/jane-eppstein">Jane Eppstein</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/jason-markk/">Jason Markk</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/karhu">Karhu</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/kowtow/">Kowtow</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/l-f-markey/">L.F Markey</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/lazy-oaf/">Lazy Oaf</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/mars">Mars</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/meadowlark/">Meadowlark</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/mina">Mina</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/new-balance/">New Balance</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/nike/">Nike</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/nobody-denim">Nobody Denim</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/norse-projects/">Norse Projects</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/parra/">Parra</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/patagonia/">Patagonia</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/perks-and-mini/">Perks And Mini </a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/prmtvo/">PRMTVO</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/reebok/">Reebok</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/rollas/">Rollas</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/slow-lane/">Slow Lane</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/stan-ray/">Stan Ray</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/stepney-workers-club">Stepney Workers Club</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/taikan-everything">Taikan Everything</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/the-fifth-label/">The Fifth Label</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/the-north-face">The North Face</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/tid-watches/">TID Watches</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/vans/">Vans</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/veja/">Veja</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/wood-wood/">Wood Wood</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="https://shop.goodasgoldshop.com/collections/yu-mei/">Yu Mei</a>
					      </b>
					    </li>
					  					    <li class="navParent">
					      <b>
					        <a href="http://goodasgoldshop.com/brands">All Brands</a>
					      </b>
					    </li>
					  					</ul>

				</li>
								<li>
					<a href="/lookbook">Lookbook</a>
				</li>
								<li>
					<a href="/blog">Blog</a>
				</li>
								<li>
					<a href="/contact">Contact</a>
				</li>
								<li>
					<a href="https://shop.goodasgoldshop.com/apps/iwish">Wishlist</a>
				</li>
								<li>
					<a href="https://shop.goodasgoldshop.com/account/login">Log In</a>
				</li>
								<li>
					<a href="https://shop.goodasgoldshop.com/account">Create Account</a>
				</li>
							</ul>

			<ul class="navList">
                				<li>
					<a href="/brands">All Brands</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/adidas-originals">Adidas Originals</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/baggu">Baggu</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/brain-dead/">Brain Dead</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/champion">Champion</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/fjallraven/">Fjallraven</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/fuct">FUCT</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/hansel-from-basel/">Hansel from Basel</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/jane-eppstein">Jane Eppstein</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/jason-markk/">Jason Markk</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/karhu">Karhu</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/kowtow/">Kowtow</a>
				</li>
                				<li>
					<a href="https://shop.goodasgoldshop.com/collections/l-f-markey/">L.F Markey</a>
				</li>
                				<ul id="mensbrands">
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-new/">New</a>
						</b>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens">View All</a>
						</b>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mindful">Mindful</a>
						</b>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-exclusives">Exclusives</a>
						</b>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-sale">Sale</a>
						</b>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-shoes">Footwear</a>
						</b>
											</li>
                    					<li>
													<a href="https://shop.goodasgoldshop.com/collections/last-pairs">Last Pairs</a>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-tops">Tops</a>
						</b>
											</li>
                    					<li>
													<a href="https://shop.goodasgoldshop.com/collections/mens-t-shirts">T-Shirts</a>
											</li>
                    					<li>
													<a href="https://shop.goodasgoldshop.com/collections/mens-shirts/">Shirts</a>
											</li>
                    					<li>
													<a href="https://shop.goodasgoldshop.com/collections/mens-hoodies-sweatshirts">Crews / Hoods</a>
											</li>
                    					<li>
													<a href="https://shop.goodasgoldshop.com/collections/mens-jackets">Jackets</a>
											</li>
                    					<li>
												<b>
							<a href="https://shop.goodasgoldshop.com/collections/mens-bottoms/">Bottoms</a>
						</b>
											</li>
                    				</ul>
				<ul id="womensbrands">
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-new/">New</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens">View All</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mindful">Mindful</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-exclusives/">Exclusives</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-sale/">Sale</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-shoes/">Footwear</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-sneakers">Sneakers</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-boots-heels-flats/">Boots, Heels &amp; Flats</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/last-pairs-womens/">Last Pairs</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-tops">Tops</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-t-shirts/">T-Shirts</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-shirts">Shirts</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-hoodies-sweatshirts">Sweaters</a>
                            						</li>
                    				</ul>
			</ul>

			<ul class="navList">
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/lazy-oaf/">Lazy Oaf</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/mars">Mars</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/meadowlark/">Meadowlark</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/mina">Mina</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/new-balance/">New Balance</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/nike/">Nike</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/nobody-denim">Nobody Denim</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/norse-projects/">Norse Projects</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/parra/">Parra</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/patagonia/">Patagonia</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/perks-and-mini/">Perks And Mini </a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/prmtvo/">PRMTVO</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/reebok/">Reebok</a>
                        					</li>
                				<ul id="mensbrands1">
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-pants/">Pants</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-denim/">Denim</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-shorts/">Shorts</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-accessories/">Accessories</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-bags/">Bags</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-watches/">Watches</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-socks">Socks</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-hats">Hats &amp; Caps</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-sunglasses">Sunglasses</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-wallets/">Wallets</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-belts">Belts</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/cases-sleeves/">Cases &amp; Sleeves</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-jewellery">Jewellery</a>
								</b>
                            						</li>
                    				</ul>
				<ul id="womensbrands1">
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-knitwear/">Knitwear</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-jackets">Jackets</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-dresses/">Dresses</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-bottoms/">Bottoms</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-pants/">Pants</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-shorts-skirts">Shorts / Skirts</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/jumpsuits">Jumpsuits</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-denim/">Denim</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-swimwear/">Swimwear</a>
								</b>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-accessories/">Accessories</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-bags">Bags</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-bags">Wallets</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-socks-and-tights">Socks &amp; Tights</a>
                            						</li>
                    				</ul>
			</ul>

			<ul class="navList">
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/rollas/">Rollas</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/slow-lane/">Slow Lane</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/stan-ray/">Stan Ray</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/stepney-workers-club">Stepney Workers Club</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/taikan-everything">Taikan Everything</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/the-fifth-label/">The Fifth Label</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/the-north-face">The North Face</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/tid-watches/">TID Watches</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/vans/">Vans</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/veja/">Veja</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/wood-wood/">Wood Wood</a>
                        					</li>
                					<li>
                        							<a href="https://shop.goodasgoldshop.com/collections/yu-mei/">Yu Mei</a>
                        					</li>
                					<li>
                        							<b>
								<a href="http://goodasgoldshop.com/brands">All Brands</a>
							</b>
                        					</li>
                				<ul id="mensbrands2">
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/mens-goods">Goods</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/fragrance/">Fragrance</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/magazines-books">Magazines &amp; Books</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-grooming-products">Grooming Products</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-stuff">Stuff</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/knives/">Knives</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/mens-gifts">Gifts</a>
                            						</li>
                    				</ul>
				<ul id="womensbrands2">
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-watches/">Watches</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-sunglasses/">Sunglasses</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-hats/">Hats &amp; Caps</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-jewellery/">Jewellery</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/hair-clips">Hair Clips</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-rings/">Rings</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-earrings/">Earrings</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-necklaces/">Necklaces</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/womens-bracelets/">Bracelets</a>
                            						</li>
                    						<li>
                            								<b>
									<a href="https://shop.goodasgoldshop.com/collections/womens-goods/">Goods</a>
								</b>
                            						</li>
                    						<li>
                            								<a href="https://shop.goodasgoldshop.com/collections/fragrance/">Fragrance</a>
                            						</li>
                    						<li>
                            								<a href="https://shop.ghttps://shop.goodasgoldshop.com/collections/womens-stuff">Stuff</a>
                            						</li>
                    				</ul>
			</ul>

			<div>
				<div>
					<form action="https://shop.goodasgoldshop.com/search" method="GET">
						<input type="text" class="search" name="q" placeholder="Search">
					</form>
				</div>
			</div>

		</div>
	</div>
	<!-- Primary Navigation -->
	<ul class="nav" id="navHandler">
		<a href="/">
			<li class="logo"></li>
		</a>
		<li class="underline">
			<a href="javascript:void(0)" id="shopOnline">Shop Online</a>
		</li>
		<li class="underline">
			<a href="https://shop.goodasgoldshop.com/collections/new-instore">New</a>
		</li>
		<li class="underline">
			<a href="http://shop.goodasgoldshop.com/collections/sale/">Sale</a>
		</li>
		<li>
			<form action="https://shop.goodasgoldshop.com/search" method="GET">
				<input type="text" class="search" name="q" placeholder="Search">
			</form>
			<button>
				<span></span>
			</button>
		</li>
		<li class="underline-secondary">
			<a href="https://shop.goodasgoldshop.com/apps/iwish">Wishlist</a>
		</li>
		<li class="underline-secondary">
			<a href="javascript:void(0)" id="cartToggle">
				<span>Cart (0)</span>
				<span class="cart-icon">
					<span>0</span>
				</span>
			</a>
		</li>
		<button class="hamburger" type="button" id="menuToggle" aria-label="Menu">
				<span class="hamburger-box">
					<span class="hamburger-inner"></span>
				</span>
		</button>
	</ul>
		<div class="backdrop " id="awSeventeen" data-colour="">
	</div>
</div>

<!-- Cart Silder -->
<div class="cart">
    <div>
        <h3>Your Cart</h3>
        <button id="cartClose">
            <span></span>
            <span></span>
        </button>
    </div>
    <div class="cart-container">
    </div>
    <div class="cart-total">
        <h3>Total</h3>
        <h3>$0.00 NZD</h3>
    </div>
        <a href="https://shop.goodasgoldshop.com/cart" class="checkout">
        <button>Checkout</button>
    </a>
    <h4>
        <a href="https://shop.goodasgoldshop.com/collections/all" id="cartContinue">Continue Shopping</a>
    </h4>
</div>
<!-- Email Silder: to activate add .is-block to
     emailOverlay and add .is-subOpen to emailSubs -->
<div class="emailSubs">
	<button id="subClose">
		<span></span>
		<span></span>
	</button>
	<h6>Newsletter</h6>
	<h3>Subscribe</h3>
	<form action="https://bitbybit.createsend.com/t/r/s/iyopt/" method="post" id="newsletter-popup">
		<div>
			<input type="text" name="cm-name" id="subName" required>
			<label for="subName">Full Name</label>
		</div>
		<div>
			<input type="email" name="cm-iyopt-iyopt" id="subEmail" required>
			<label for="subEmail">Email Address</label>
		</div>
		<div>
			<button>Submit</button>
		</div>
	</form>
</div>

<div class="emailOverlay"></div>

<!-- Wellington Store Info Silder -->
<div class="storeInfo" id="wellingtonStore">
	<div>
		<h3>Store Info</h3>
		<button class="storeClose">
			<span></span>
			<span></span>
		</button>
	</div>
	<h3>
		Wellington
	</h3>
	<div>
		<div class="image-block" style="background-image: url(/images/gagwelly01_c0837e9f-07e1-4e68-93e8-c250548381d5_x300.jpg);">
		</div>
	</div>
	<div>
				<h3>
			111 Victoria Street
		</h3>
				<h3>
			Wellington
		</h3>
				<h3>
			New Zealand
		</h3>
						<a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2997.867427093689!2d174.77360541542276!3d-41.289989679273205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d38afd6568bcc6b%3A0x235f0581ccb2f422!2s111+Victoria+St%2C+Te+Aro%2C+Wellington+6011!5e0!3m2!1sen!2snz!4v1530565855269" target="_blank" class="map">View Map</a>
        		<h3>
			<a href="tel:+6443814653">+64 4 381 4653</a>
		</h3>
	</div>
	<h3>Opening Hours</h3>
			<h3>Monday – Thursday: 10.00am – 5.30pm</h3>
			<h3>Friday: 10.00am – 6.00pm</h3>
			<h3>Saturday: 10.30am – 5.00pm</h3>
			<h3>Sunday: 11.00am – 4.00pm</h3>
	</div>

<!-- Overlay triggered with Stores and Cart to assist functionality -->
<div class="overlay" id="cardOverlay">
</div>

<div class="screensaver">
	<canvas id="canvas">
	</canvas>
</div>

    						<div class="cover-2 container js-color-trigger" data-colour="#e6e6e6">
			<div>
                                <a href="https://justtheticketnz.com/events/495c4ccd-497f-af67-05a6-68819362932a">				<div class="image-block" style="background-image: url(/images/HOMEPAGE_BANNER.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="PARTY ">PARTY </p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="PARTY ">PARTY </p>
				</div>
			</div>
			<h5></h5>
		</div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#fdd5ac">
			<h3>Stan Ray </h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/stan-ray/">				<div class="image-block" style="background-image: url(/images/stanrayhomepagebanner.jpg);"></div>
                </a>			</div>
			<p>Tried and true since 1972. Stan Ray is a family company born and still based in Texas, USA. To put it simply, they make clothes designed for easy wear and movement with minimum fuss and maximum practicality. Easy!
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/stan-ray/">Shop Stan Ray here.</a></u></strong>
<br></br></p>
		</div>
        			        <div class="product-container js-color-trigger" id="content" data-colour="#d8ebf2">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/e1892edeb9f84ac768a2f60967ceadc94d98dd6b.jpg?v=1568783068);">
                    <a href="https://shop.goodasgoldshop.com/products/shop-jacket-sandstone-brown"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/shop-jacket-sandstone-brown">
                            <p>Shop Jacket - sandstone brown</p>
                            <p>JACKETS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/shop-jacket-sandstone-brown">$289.95 </a>
                    </div>
                    <div class="product-container__sizes" >
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/shop-jacket-sandstone-brown?variant=30116545298495">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/411631a886baaaddf6bfcd5199f8cf7e29f073a1.jpg?v=1568782998);">
                    <a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe">
                            <p>Flannel Shirt - flag:CX123 old yellow stripe</p>
                            <p>SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe">$249.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe?variant=30116545101887">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe?variant=30116545134655">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/flannel-shirt-old-yellow-stripe?variant=30116545167423">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/5ae44c55d3090f444e466d386ba2a952176f68e2.jpg?v=1568782801);">
                    <a href="https://shop.goodasgoldshop.com/products/workers-hood-midnight-blue"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/workers-hood-midnight-blue">
                            <p>Workers Hood - midnight blue</p>
                            <p>HOODIES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/workers-hood-midnight-blue">$229.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/workers-hood-midnight-blue?variant=30116544774207">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/workers-hood-midnight-blue?variant=30116544806975">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/a1a274451f787e7a8b62d86a0919f76597bc7620.jpg?v=1568782461);">
                    <a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green">
                            <p>Stan T-Shirt - forest green</p>
                            <p>T-SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green">$79.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green?variant=30116544446527">LARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green?variant=30116544479295">XLARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/stan-t-shirt-forest-green?variant=30116544512063">XXLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-2 container js-color-trigger" data-colour="#d8ebf2">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/fuct">				<div class="image-block" style="background-image: url(/images/fucthomepagebanner.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="FUCT">FUCT</p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="FUCT">FUCT</p>
				</div>
			</div>
			<h5>FUCT (Friends U Can&#039;t Trust) is a clothing brand founded in Los Angeles in 1990 by artist and designer Erik Brunetti and skater Natas Kaupas. 29 years ago!! Crazy. Skate culture is their roots but they&#039;re well known for incorporating pop culture iconography into their own branding.

We welcome FUCT back onto the GAG racks after a few years hiatus ~ one of the OG pioneering brands for modern streetwear clothing today.

You should get FUCT, it&#039;s some clever stuff and we&#039;re stoked to have them back.</h5>
		</div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#b4cac2">
			<h3>Mina</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/mina/">				<div class="image-block" style="background-image: url(/images/minabanner.jpg);"></div>
                </a>			</div>
			<p>Consciously designed and made in New Zealand.
<br></br>
Natalie and her Mum create each piece with the desire for less. Each collection will excite with refined silhouettes but will hold true to a ﻿core collection of versatile staples. Simple elegance at it's very best.
<br></br>
Mina is a proudly local brand supporting and highlighting our extremely talented group of hands we have here in New Zealand.
<br></br>
We're very happy to welcome Mina to Good As Gold.
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/mina/">Shop Mina here.</a></u></strong>
<br></br></p>
		</div>
        			        <div class="product-container js-color-trigger" id="content" data-colour="#b4cac2">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/87ac7f20adaa996f74fcaa217a30f1b2deb7b83c.jpg?v=1568256167);">
                    <a href="https://shop.goodasgoldshop.com/products/willow-dress-sage"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/willow-dress-sage">
                            <p>Willow Dress - sage</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/willow-dress-sage">$295.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/willow-dress-sage?variant=16026689798207">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/willow-dress-sage?variant=16026689830975">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/willow-dress-sage?variant=16026689863743">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/f017bc9361c193192f7aae85a558e4c9184aba19.jpg?v=1568256792);">
                    <a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe">
                            <p>Runaway Shirt - sage stripe</p>
                            <p>SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe">$325.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe?variant=16026845315135">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe?variant=16026845347903">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/runaway-shirt-sage-stripe?variant=16026845380671">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/51b7c413a87cc809224c4996e8a76922f5ff79a0.jpg?v=1568257349);">
                    <a href="https://shop.goodasgoldshop.com/products/honey-dress-cream"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/honey-dress-cream">
                            <p>Honey Dress - cream</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/honey-dress-cream">$325.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/honey-dress-cream?variant=16026888208447">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/honey-dress-cream?variant=16026888241215">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/honey-dress-cream?variant=16026888273983">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/1c2437e7535ebaf1273cb1912b999bf9e0894ffe.jpg?v=1568256483);">
                    <a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue">
                            <p>Sunlight Dress - cornflower blue</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue">$329.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue?variant=16026762444863">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue?variant=16026762477631">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sunlight-dress-cornflower-blue?variant=16026762510399">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-2 container js-color-trigger" data-colour="#005334">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/adidas-originals">				<div class="image-block" style="background-image: url(/images/Adidas_Tempo.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text=""></p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text=""></p>
				</div>
			</div>
			<h5>Adidas TEMPER RUN ~ Along with a few other new arrivals, some of the coolest ones we&#039;ve seen in a while ~ We got full size ranges so you can all get amongst it</h5>
		</div>
					        <div class="product-container js-color-trigger" id="content" data-colour="#005334">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/a66eb8e8d7adfa79e869cb1ab6c1356f72907e43_d876233a-b25b-458d-8fb8-71ed69333a36.jpg?v=1567481541);">
                    <a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black">
                            <p>Yung-1 - crystal white/grey one/core black</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black">$199.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245006399">US 6<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245039167">US 6.5<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245104703">US 8<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245137471">US 9<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245170239">US 5<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245203007">US 10<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/yung-1-crystal-white-grey-one-core-black?variant=15936245235775">US 11<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/927e4e17a353536142071a09656b8eba67f09d0e.jpg?v=1567120619);">
                    <a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange">
                            <p>Temper Run - grey/green/orange</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange">$210.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange?variant=15904821280831">US 6.5<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange?variant=15904821379135">US 8<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange?variant=15904821444671">US 10<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/temper-run-grey-green-orange?variant=15904821477439">US 11<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/adidas_ozweego_white1.jpg?v=1564698043);">
                    <a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black">
                            <p>Ozweego - cloud/white/black</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black">$199.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black?variant=15630155579455">US 7<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black?variant=15630155612223">US 8<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black?variant=15630155644991">US 9<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ozweego-cloud-white-black?variant=15630155677759">US 10<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/f1b88def66b09e635315d0c420b041fff2603179.jpg?v=1564007043);">
                    <a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange">
                            <p>Sobakov 2.0 - black/ solar orange</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange">$250.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218538047">US 6<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218570815">US 6.5<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218603583">US 7<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218669119">US 9<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218701887">US 10<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/sobakov-20-black-solar-orange?variant=15536218734655">US 11<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#e6e6e6">
			<h3>No Comply | Issue 5</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/no-comply///">				<div class="image-block" style="background-image: url(/images/nocomplybannermindful.jpg);"></div>
                </a>			</div>
			<p>Inspired by an academic staple - the Oxford University crew, this issue features a white oversized chest print complete with mystery Latin motto.
Nullus est liber tam malus ut non aliqua parte prosit. It's true.
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/no-comply///">SHOP ISSUE 5 HERE</a></u></strong></p>
		</div>
        					<div class="cover-2 container js-color-trigger" data-colour="#ffffff">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/kowtow">				<div class="image-block" style="background-image: url(/images/kowtow_home.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text=""></p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text=""></p>
				</div>
			</div>
			<h5>------------------------------ NEW ARRIVALS FROM KOWTOW ------------------------------
</h5>
		</div>
					        <div class="product-container js-color-trigger" id="content" data-colour="#ffffff">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/kowtow_triangledress_flower2.jpg?v=1568600502);">
                    <a href="https://shop.goodasgoldshop.com/products/triangle-dress-sketch-print"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/triangle-dress-sketch-print">
                            <p>Triangle Dress - sketch print</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/triangle-dress-sketch-print">$289.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/triangle-dress-sketch-print?variant=15947170971711">XXSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/triangle-dress-sketch-print?variant=15947171004479">XSMALL<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/kowtow_longslip_black1.jpg?v=1568600542);">
                    <a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black">
                            <p>Ada Long Slip Dress - black</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black">$249.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black?variant=15947082367039">XXSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black?variant=15947082432575">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black?variant=15947082465343">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ada-long-slip-dress-black?variant=15947082498111">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/kowtow_cullottes_flower3.jpg?v=1568600223);">
                    <a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print">
                            <p>Culottes - sketch print</p>
                            <p>PANTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print">$255.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print?variant=15947416731711">XXSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print?variant=15947416797247">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/culottes-sketch-print?variant=15947416830015">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/kowtow_shortslip_black1.jpg?v=1568600125);">
                    <a href="https://shop.goodasgoldshop.com/products/ada-slip-dress-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/ada-slip-dress-black">
                            <p>Ada Slip Dress - black</p>
                            <p>DRESSES</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/ada-slip-dress-black">$199.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/ada-slip-dress-black?variant=15947444158527">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ada-slip-dress-black?variant=15947444224063">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#f3dbdb">
			<h3>BAGGU</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/baggu/">				<div class="image-block" style="background-image: url(/images/bagguhomepagebetter.jpg);"></div>
                </a>			</div>
			<p>Based in San Francisco, Baggu create delightful bags that make our everyday lives easier and more enjoyable. The bags are consciously designed to create as little wastage as possible, using sustainable materials. </p>
		</div>
        			        <div class="product-container js-color-trigger" id="content" data-colour="#f3dbdb">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/410adf784f3464d7aa7343d1f161fc038296ab5d.jpg?v=1567477741);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-blue"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-blue">
                            <p>Standard Baggu - big check blue</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-blue">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-blue?variant=15936288391231">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/4d5bcc2d5ff9002f36c46d6d50739c297c98f4fc.jpg?v=1567480494);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-blue-tweed"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-blue-tweed">
                            <p>Standard Baggu - blue tweed</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-blue-tweed">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-blue-tweed?variant=15936287932479">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/2ba2b59698a16662601a0e9ec79bd825e8ecc286.jpg?v=1567479876);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-magenta"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-magenta">
                            <p>Standard Baggu - big check magenta</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-magenta">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-big-check-magenta?variant=15936288161855">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/988f2f49bdeed6dc43941535534424b5ddbadb3f.jpg?v=1564698016);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-green-hunter-stripe"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-green-hunter-stripe">
                            <p>Standard Baggu - green hunter stripe</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-green-hunter-stripe">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-green-hunter-stripe?variant=15630173962303">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/baggu_standardbaggu_scarf2.jpg?v=1567480175);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-scarf-stripe"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-scarf-stripe">
                            <p>Standard Baggu - scarf stripe</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-scarf-stripe">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-scarf-stripe?variant=15936287899711">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/3aea0de3f30438f86999c81402480361d85149ed.jpg?v=1564697683);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-yellow-happy"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-yellow-happy">
                            <p>Standard Baggu - yellow happy</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-yellow-happy">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-yellow-happy?variant=15630119174207">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/6838988a3b2e70badd30dd20eef4ddb807c65d67.jpg?v=1567477941);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-market-red"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-market-red">
                            <p>Standard Baggu - market red</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-market-red">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-market-red?variant=15936288227391">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/5d165670d8f3d1014954e7b875674c9ee354e078.jpg?v=1567480357);">
                    <a href="https://shop.goodasgoldshop.com/products/standard-baggu-glen-plaid"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-glen-plaid">
                            <p>Standard Baggu - glen plaid</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/standard-baggu-glen-plaid">$25.00 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/standard-baggu-glen-plaid?variant=15936287866943">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-2 container js-color-trigger" data-colour="#fdd5ac">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/new-instore/products/issue-26-the-rhythms-issue">				<div class="image-block" style="background-image: url(/images/hypebeastbannerhomepage.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="HYPEBEAST">HYPEBEAST</p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="HYPEBEAST">HYPEBEAST</p>
				</div>
			</div>
			<h5>HYPEBEAST Magazine Issue 26: The Rhythms Issue is now available for pre-order! Ours is a world where we can never go fast enough: rife with generalised anxiety and burnout plaguing an overworked, over-connected population. When else in history were we able to learn a new language, answer an email, make dinner plans and walk a friend through an emotional crisis within the same 5 minutes?

We want to slow down. We want to discover how we&#039;d fare on our own, without being hurried along by external forces that don&#039;t really matter; we want to know how it feels when our circadian rhythms aren&#039;t dictated by the light from our phones. With The Rhythms Issue, we wanted to show what may happen, when we&#039;re not siphoning every second of our time into serving a purpose.</h5>
		</div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#d8d0db">
			<h3>Perks and Mini</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/perks-and-mini/">				<div class="image-block" style="background-image: url(/images/PAMFORHOMEPAGE.jpg);"></div>
                </a>			</div>
			<p>Perks And Mini always deliver crazy fun hectic-ness in the very best way. The new arrivals consist of the best fitting tees and shirts - a little bit boxy, a little bit cropped, that happy medium you know what I’m sayin. All with very cool prints of course. We got accessories - scarves, socks and hats. And the most amazing god damn bomber jacket in the history of god damn amazing bomber jackets. You’re basically buying 2 jackets because this shit is REVERSIBLE!
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/perks-and-mini///">IT’S A P.A.M. WORLD, WE’RE JUST LIVING IN IT</a></u></strong></p>
		</div>
        			        <div class="product-container js-color-trigger" id="content" data-colour="#d8d0db">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/a86545cca5f5f45d7ad69f7525bdefbfd3cb716f.jpg?v=1567388587);">
                    <a href="https://shop.goodasgoldshop.com/products/disc-man-tie-die-t-shirt-rust-dye"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/disc-man-tie-die-t-shirt-rust-dye">
                            <p>Disc Man Tie Die T-Shirt - rust dye</p>
                            <p>T-SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/disc-man-tie-die-t-shirt-rust-dye">$329.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/disc-man-tie-die-t-shirt-rust-dye?variant=15835500675135">XLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/09b5529a63b85924f5bfe8e72f5d074539429c1d.jpg?v=1566448369);">
                    <a href="https://shop.goodasgoldshop.com/products/beyonde-bomber-jacket-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/beyonde-bomber-jacket-black">
                            <p>Beyonde Bomber Jacket - black</p>
                            <p>JACKETS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/beyonde-bomber-jacket-black">$789.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/beyonde-bomber-jacket-black?variant=15832640258111">LARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/e14d7cbf7818933814732441360eb3c7deecb66e.jpg?v=1567388807);">
                    <a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black">
                            <p>Flight Time T-Shirt - black</p>
                            <p>T-SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black">$119.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black?variant=15832691245119">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black?variant=15832691277887">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black?variant=15832691310655">LARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/flight-time-t-shirt-black?variant=15832691343423">XLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/0c1726b31ad888cb4b9f5c474ffe23bcd6dbbe5d.jpg?v=1566449025);">
                    <a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black">
                            <p>Calm Clouds T-Shirt - black</p>
                            <p>T-SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black">$109.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black?variant=15832742559807">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black?variant=15832742592575">LARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/calm-clouds-t-shirt-black?variant=15832742625343">XLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#b4cac2">
			<h3>Brain Dead | Pre-Fall 19</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/brain-dead">				<div class="image-block" style="background-image: url(/images/braindeadhomepagebanner.jpg);"></div>
                </a>			</div>
			<p>Brain Dead is a collective group of artists and designers from all around the world coming together to make cool shit. Always interesting and could even say a little disruptive, the graphics often making us think twice. Available in New Zealand exclusively through GAG which we're real stoked about.
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/brain-dead/">GET SET...GO!</a></u></strong>
<br></br></p>
		</div>
        					<div class="cover-2 container js-color-trigger" data-colour="#f1cab9">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/karhu">				<div class="image-block" style="background-image: url(/images/karhuhomepagebanner.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="KARHU">KARHU</p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="KARHU">KARHU</p>
				</div>
			</div>
			<h5>First introduced in 1996, the Legacy featured an Air Cushion landing zone, sandwich construction heel cap, and an EVA midsole to make a well-cushioned running shoe. Leaving no wish unfulfilled, the inherently stable design provided a comfortable ride. Today, the Legacy 96 pays homage to past endeavours not forgotten while looking for future adventures.</h5>
		</div>
							<div class="cover-2 container js-color-trigger" data-colour="#d8ebf2">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/veja">				<div class="image-block" style="background-image: url(/images/New-Arrival-Homepage-Banner.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="VEJA">VEJA</p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="VEJA">VEJA</p>
				</div>
			</div>
			<h5>Everyone’s favourite ethical sneaker is back!!! Hello VEJA, it&#039;s so nice to see you. The idea behind a pair of Veja&#039;s: standing up with ⁠one foot in design and the other in ⁠social responsibility &#x1f44f; Make an ethical choice and looking real good while doing it, that&#039;s just the best.  From the initial stages of production, gathering the raw materials etc, to the the point where you try your shoes on in the shop, Veja ensures the highest ethical standard is never compromised &#x1f44a; ⁠</h5>
		</div>
					        <div class="product-container js-color-trigger" id="content" data-colour="#d8ebf2">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/99b32ed3e4a97a4210470e6e66db4767877ba79a.jpg?v=1564975191);">
                    <a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala">
                            <p>Riobranco Hexamesh - gravel/black/marsala</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala">$219.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883800639">EU 37<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883833407">EU 38<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883866175">EU 39<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883931711">EU 41<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883964479">EU 42<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655883997247">EU 43<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/riobrancohexamesh-gravelblackmarsala?variant=15655884062783">EU 45<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/c3350868ec2f732291a4531ef8d13de2251b97e2.jpg?v=1564975691);">
                    <a href="https://shop.goodasgoldshop.com/products/v10-leather-extra-white-pekin-cobalt-tonic"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/v10-leather-extra-white-pekin-cobalt-tonic">
                            <p>V10 Leather - extra white/pekin/cobalt/tonic</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/v10-leather-extra-white-pekin-cobalt-tonic">$229.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/v10-leather-extra-white-pekin-cobalt-tonic?variant=15655868530751">EU 36<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/c9c11e78a9164bb5c9dde186b159255529c62369.jpg?v=1564975487);">
                    <a href="https://shop.goodasgoldshop.com/products/v12-b-mesh-white-black"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/v12-b-mesh-white-black">
                            <p>V12 B Mesh - white/black</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/v12-b-mesh-white-black">$219.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/v12-b-mesh-white-black?variant=15655872954431">EU 39<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/e0445b4afe5ff26dffa9e40959099788707c05a0.jpg?v=1564978574);">
                    <a href="https://shop.goodasgoldshop.com/products/v-10-b-mesh-natural-marsala"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/v-10-b-mesh-natural-marsala">
                            <p>V10 BMesh - natural/marsala</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/v-10-b-mesh-natural-marsala">$219.95 Sold Out</a>
                    </div>
                    <div class="product-container__sizes">
                                                <a href="https://shop.goodasgoldshop.com/products/v-10-b-mesh-natural-marsala">
                            <p>Sold Out</p>
                        </a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#b4cac2">
			<h3>Wood Wood</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/wood-wood/">				<div class="image-block" style="background-image: url(/images/homepagebanner.jpg);"></div>
                </a>			</div>
			<p>Wood Wood started in 2002 and is based in Denmark Copenhagen. Their pieces are synonymous with clean Euro design, always top quality and timeless. Super super nice stuff. We can't rave enough!</p>
		</div>
        			        <div class="product-container js-color-trigger" id="content" data-colour="#b4cac2">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/ww2.psd_0024_wood-wood-falcon-sweater_1600x2400c-2.jpg?v=1566249575);">
                    <a href="https://shop.goodasgoldshop.com/products/falcon-sweater-bright-green"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/falcon-sweater-bright-green">
                            <p>Falcon Sweater - bright green</p>
                            <p>SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/falcon-sweater-bright-green">$249.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/falcon-sweater-bright-green?variant=15802814857279">LARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/falcon-sweater-bright-green?variant=15802814890047">XLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/ww2.psd_0027_wood-wood-fabian-shirt_1600x2400c-2.jpg?v=1566249623);">
                    <a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe">
                            <p>Fabian Shirt - taupe</p>
                            <p>SHIRTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe">$249.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe?variant=15802814922815">MEDIUM<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe?variant=15802814955583">LARGE<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/fabianshirt-taupe?variant=15802814988351">XLARGE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/ww2.psd_0021_wood-wood-tilda-sweater_1600x2400c-2.jpg?v=1566249661);">
                    <a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green">
                            <p>Tilda Knit Sweater - bright green</p>
                            <p>KNITWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green">$279.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green?variant=15802815053887">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green?variant=15802815086655">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/tilda-knit-sweater-bright-green?variant=15802815119423">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/ww2.psd_0029_wood-wood-asta-sweater_1600x2400c-4.jpg?v=1566249686);">
                    <a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue">
                            <p>Asta Knit Sweater  - dusty blue</p>
                            <p>SWEATERS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue">$229.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue?variant=15802815545407">XSMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue?variant=15802815578175">SMALL<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/asta-knit-sweater-dusty-blue?variant=15802815610943">MEDIUM<span> / </span></a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-2 container js-color-trigger" data-colour="#f3dbdb">
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/jaggar/">				<div class="image-block" style="background-image: url(/images/jaggarbanner.jpg);"></div>
                </a>			</div>
			<div>
				<div class="marquee-ltr">
					<p data-text="JAGGAR">JAGGAR</p>
				</div>
			</div>
			<div>
				<div class="marquee-vert">
					<p data-text="JAGGAR">JAGGAR</p>
				</div>
			</div>
			<h5></h5>
		</div>
					        <div class="product-container js-color-trigger" id="content" data-colour="#f3dbdb">
            <h3>New Arrivals</h3>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/c21ba4ba28f93d21011887823c6a459b03fa82de.jpg?v=1565569415);">
                    <a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink">
                            <p>Ruched Kitten Heel - candy pink</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink">$219.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink?variant=15735054860351">EU 36<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink?variant=15735054893119">EU 37<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink?variant=15735054925887">EU 38<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/ruched-kitten-heel-candy-pink?variant=15735054958655">EU 39<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/9dde8db35c764345eb07407ee469480a657a4ca3.jpg?v=1565569796);">
                    <a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede">
                            <p>Solace Slingback Pump - chocolate suede</p>
                            <p>FOOTWEAR</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede">$229.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede?variant=15735055220799">EU 36<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede?variant=15735055253567">EU 37<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede?variant=15735055286335">EU 38<span> / </span></a><a href="https://shop.goodasgoldshop.com/products/solaceslingbackpump-chocolatesuede?variant=15735055319103">EU 39<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/4a59ee80f00f0bcdb2c9fe5203e237f269650966.jpg?v=1558408802);">
                    <a href="https://shop.goodasgoldshop.com/products/belt-bag-sage-houndstooth"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/belt-bag-sage-houndstooth">
                            <p>Belt Bag - sage houndstooth</p>
                            <p>BAGS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/belt-bag-sage-houndstooth">$159.95 </a>
                    </div>
                    <div class="product-container__sizes">
                                                    <p>Available Sizes</p>
                                            <a href="https://shop.goodasgoldshop.com/products/belt-bag-sage-houndstooth?variant=14963065716799">ONE SIZE<span> / </span></a>
                                            </div>
                </div>
            </div>


            <div class="textToggle">
                <div class="image-block" style="background-image: url(https://cdn.shopify.com/s/files/1/0039/3312/products/eac8c9e17654ea68418009316dd682272120ffd5.jpg?v=1558409265);">
                    <a href="https://shop.goodasgoldshop.com/products/buckle-belt-orange-houndstooth"></a>
                </div>
                <div class="text-block">
                    <div>
                        <a href="https://shop.goodasgoldshop.com/products/buckle-belt-orange-houndstooth">
                            <p>Buckle Belt - orange houndstooth</p>
                            <p>BELTS</p>
                        </a>
                        <a href="https://shop.goodasgoldshop.com/products/buckle-belt-orange-houndstooth">$69.95 Sold Out</a>
                    </div>
                    <div class="product-container__sizes">
                                                <a href="https://shop.goodasgoldshop.com/products/buckle-belt-orange-houndstooth">
                            <p>Sold Out</p>
                        </a>
                                            </div>
                </div>
            </div>
                    </div>
							<div class="cover-3 container markdown js-color-trigger" data-colour="#d8ebf2">
			<h3>Meadowlark | SOLIS</h3>
			<div>
                                <a href="https://shop.goodasgoldshop.com/collections/meadowlark">				<div class="image-block" style="background-image: url(/images/meadowlarkbanner.jpg);"></div>
                </a>			</div>
			<p>Inspired by America's vast, strange Southwest, the latest collection from Meadowlark is here. Startling rock formations and uneven shapes come together with gleaming precious metals and juicy freshwater pearls in clever assemblages, while the series of signet rings take their names from LA's most iconic streets.
<br></br>
<strong><u><a href="https://shop.goodasgoldshop.com/collections/meadowlark//">Shop SOLIS here.</a></u></strong>
<br></br></p>
		</div>
        			        <div class="cover-4 container js-color-trigger" data-colour="#e6e6e6">
            <div>
                                                <div class="image-block" style="background-image: url(/images/homepagebday.png);"></div>
                            </div>
            <div class="marquee-ltr">
                <p data-text="LET&#039;S PARTY">LET&#039;S PARTY</p>
            </div>
            <h5>It&#039;s our 15th birthday yo ~ 21st September 7pm-1am ~ Meow, Edward Street ~ Come celebrate 15 years of independent retail with us</h5>
        </div>

<footer class="footer container ">
    <div>

                        <ul>
            <li>
                <a href="https://shop.goodasgoldshop.com/collections/new-instore">Shop Online</a>
            </li>
                            <li location="0">
                                            <a href="https://shop.goodasgoldshop.com/collections/new-instore" id="">New In</a>
                                    </li>
                            <li location="0">
                                            <a href="https://shop.goodasgoldshop.com/collections/womens" id="">Womens</a>
                                    </li>
                            <li location="0">
                                            <a href="https://shop.goodasgoldshop.com/collections/mens" id="">Mens</a>
                                    </li>
                            <li location="0">
                                            <a href="/brands" id="">Brands</a>
                                    </li>
                            <li location="0">
                                            <a href="https://shop.goodasgoldshop.com/collections/all/sale" id="">Sale</a>
                                    </li>
                    </ul>
                                                                                                                <ul>
            <li class="activeAncestor">
                <a href="javascript:void(0);">Wellington Store</a>
            </li>
                            <li location="1">
                                            111 Victoria Street
                                    </li>
                            <li location="1">
                                            Wellington
                                    </li>
                            <li location="0">
                                            <a href="tel:+6449136061" id="">+64 4 381 4653</a>
                                    </li>
                            <li location="0">
                                            <a href="javascript:void(0);" id="wellyOpen">More Info</a>
                                    </li>
                    </ul>
                                                                                                <ul>
            <li>
                <a href="https://www.instagram.com/goodasgoldshop/">Follow Us</a>
            </li>
                            <li location="0">
                                            <a href="https://www.instagram.com/goodasgoldshop/" id="">Instagram</a>
                                    </li>
                            <li location="0">
                                            <a href="https://www.facebook.com/shopGoodAsGold/" id="">Facebook</a>
                                    </li>
                            <li location="0">
                                            <a href="http://gagdump.tumblr.com/" id="">Image Dump</a>
                                    </li>
                            <li location="0">
                                            <a href="/lookbook" id="">Lookbook</a>
                                    </li>
                    </ul>
                                                                                                <ul>
            <li>
                <a href="/contact">Contact</a>
            </li>
                            <li class="phone-number" location="0">
                                            <a href="tel:+6449136061" id="">+64 4 913 6061</a>
                                    </li>
                            <li location="0">
                                            <a href="/cdn-cgi/l/email-protection#f1989f979eb1969e9e959082969e9d95df929edf9f8b" id="">Email Us</a>
                                    </li>
                            <li location="0">
                                            <a href="https://goodasgoldshop.com/customer-care" id="">Help</a>
                                    </li>
                    </ul>
                                                                                <ul>
            <li>
                <a href="/about">About Us</a>
            </li>
                            <li location="0">
                                            <a href="/distribution" id="">Distribution</a>
                                    </li>
                            <li location="0">
                                            <a href="https://goodasgoldshop.com/careers" id="">Careers</a>
                                    </li>
                    </ul>
                                                    </div>
    <ul>
        <li>
            <a href="javascript:void(0)" id="shippingToggle">Shipping &amp; Delivery</a>
        </li>
        <li>
            <a href="javascript:void(0)" id="careersToggle">Customer Care</a>
        </li>
        <li>
            <a href="javascript:void(0)" id="returnsToggle">Returns</a>
        </li>
    </ul>
    <a href="javascript:void(0)" id="js-subLink">
        <div>Signup to our newsletter</div>
    </a>
    <ul>
    </ul>
    <div>
        <button id="scrollTotop"></button>
    </div>

        <a href="https://justtheticketnz.com/events/495c4ccd-497f-af67-05a6-68819362932a?fbclid=IwAR0yaosN2Yw0gnCSNXW6asKyKDuvnCBXS_FRYfAhkgLgKGTMRft8p8V1Ff8" class="announcement-l" style="background-color: #5ef603" >
        <div class="marquee-anno">
            <p data-text="Get your party tickets here">Get your party tickets here</p>
        </div>
    </a>
    </footer>
<div class="container" id="shippingInfo">
    <div>
        <p>Shipping &amp; Delivery</p>
        <button class="footerclose">
            <span></span>
            <span></span>
        </button>
    </div>
    <div class="markdown">
        <h5>New Zealand:<br /></h5>
<p>Free courier delivery when you spend over $99.00.<br />
Purchases under $99.00 will be charged $5.00 for courier delivery.<br />
We aim to deliver all NZ orders with a 1-2 day courier service, but occasionally in busy times orders can take 2-4 days. <br />
<br />
<br />
<br /></p>
<h5>Australia:<br /></h5>
<p>Free shipping when you spend over $99.00 (NZD).<br />
Purchases under $99.00 (NZD) will be charged $15.00 (NZD) for shipping.<br />
Our standard Shipping to Australia takes 7-14 days.<br />
<br />
<br /></p>
<h5>Rest Of The World:<br /></h5>
<p>Free shipping when you spend over $299.00 (NZD).<br />
Purchases under $299.00 (NZD) will incur the following shipping charge:<br />
USA $29.00<br />
Canada $45.00<br />
Europe $29.00<br />
UK $49.00<br />
Hong Kong/Singapore/Thailand $29.00<br />
Japan $40.00<br />
<br />
<a href="/shipping">Click here for detailed shipping information</a></p>
    </div>
</div>
<div class="container" id="careers">
    <div>
        <p>Customer Care</p>
        <button class="footerclose">
            <span></span>
            <span></span>
        </button>
    </div>
    <div class="markdown">
        <p>We love to look after our customers and answer all your questions the best we can. From finding about online orders, what payment methods are provided, warranties and everything else between we aim to aid you during your time of great great need. In saying all of that if you&#039;d rather just read up on everything follow the link!<br />
<br />
<a href="/customer-care">Read More</a></p>
    </div>
</div>
<div class="container" id="returns">
    <div>
        <p>Returns</p>
        <button class="footerclose">
            <span></span>
            <span></span>
        </button>
    </div>
    <div class="markdown">
        <p>Full priced items may be returned for a credit with Good as Gold within 7 days of receipt for New Zealand purchases, and 10 days of receipt for international purchases.<br />
<br />
Contact must be made via <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="f39a9d959cb3949c9c979280949c9f97dd909cdd9d89">[email&#160;protected]</a> within 48 hours of receiving the goods advising us of return.<br />
<br />
Returned items must not have been worn, altered or washed and must have all original tags and packaging intact.<br />
<br />
Shipping and handling is non refundable and returns are the customers responsibility until they reach Good as Gold Ltd.<br />
<br />
Discounted items or Items purchased with special offer discount codes are final sale and cannot be returned or refunded.<br />
<br />
<a href="/customer-care">Read More</a></p>
    </div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="/js/noframework.waypoints.min.js"></script>
<script src="/js/hammer.min.js"></script>
<script src="/js/smoothscroll.min.js"></script>
<script src="/js/index.js"></script>
<script src="/js/cart.js"></script>

	<script>
    setTimeout(function () {
        $('.emailSubs').addClass('is-subOpen');
        $('.emailOverlay').addClass('is-block');
    }, 10000)
</script>


</body>

</html>
