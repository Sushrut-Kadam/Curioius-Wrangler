<html>
<body>
  <h1>METHOD TO SOLVE</h1>
  
<h3>A=B B=A C=Z D=Y E=X F=W G=V H=U I=T J=S K=R L=Q M=P N=O O=N P=M Q=L R=K S=J T=I U=H V=G W=F X=E Y=D Z=C</h3>

<div>
<a href="index1.php"><button id="homelink">Go To Homepage</button></a>
</div>

</body>
</html>
