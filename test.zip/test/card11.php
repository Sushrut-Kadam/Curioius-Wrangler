<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<!-- <link rel="stylesheet" href="Styling.css"> -->
</head>


<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>


<font color="black">
<body id="banner_image12">


  <h1><center>Rubbish </center></h1>

  <center><h3><strong>Description:</strong></h3></center>
            <center><h5>Patience is bitter, but its fruit is sweet</h5></center>

            <center><h3><strong>Hint: </strong></h3></center>
            <center><h5>Reading carefully completely justifies your patience</h5></center>
        </div>

        <div col-lg-12 class='body'>
             <h1 class="entry-title">Definitions</h1>
	     <p>The following terminology is used to define and indicate the source of authority for the issuance of various policies, regulations and rules (PRRs) by which the institution governs itself. Policies, regulations and rules directly or substantially affect procedural or substantive rights and duties of individuals that interact with the University.</p>
<p><strong>Policy:</strong><br />
A policy is any standard, statement, or procedure of general applicability adopted by the Board of Trustees pursuant to authority delegated by law or the Board of Governors.</p>
<p><strong>Regulation:</strong><br />
A regulation is any standard, statement (which may include a policy statement), or procedure of general applicability adopted by the chancellor or chancellor's delegee that addresses any of the following matters:</p>
<ol>
<li>Compliance with fiscal, academic, research, human relations, or other management standards and requirements imposed by federal or state laws or implementing regulations;</li>
<li>Procedures and reporting requirements related to implementation or compliance with policies of the Board of Governors or Board of Trustees, or regulations of the Office of the President;</li>
<li>Matters not specifically addressed in Board of Governors or Board of Trustees policies or regulations of the Office of the President that are within the general nature of the chancellor's delegated responsibilities to administer the institution.</li>
</ol>
<p><strong>Rule:</strong><br />
A Rule is a standard, statement or procedure, other than a policy or regulation, adopted by an academic or administrative unit of NC State University to implement a NC State University Policy or Regulation or address matters within the operational authority of the unit. A Rule may supplement but not conflict with policies and regulations. Academic unit Rules other than those that are required to be established by UNC or NCSU policies or regulations must be approved by the Dean of the applicable college or the Vice Provost of the applicable academic unit. All other rules, i.e. issued by administrative units, must be approved by the unit administrator and the executive officer to whom the unit reports.</p>
<p><strong>Each PRR has header information described below:</strong></p>
<ul>
<li><strong>Authority:</strong> Cites the position or entity that has the authority to approve and issue the PRR.</li>
<li><strong>History:</strong> Presents the dates of the PRR's first issuance; dates of any revisions to the PRR; and, any additional history information that may assist in understanding the evolution of the PRR.</li>
<li><strong>Related Policies:</strong> Provides references and links to policies that provide additional information or context for the PRR.</li>
<li><strong>Additional References:</strong> Provides statutory references, web site references, or other PRR related information.</li>
<li><strong>Contact Info:</strong> Lists the position or office to contact to obtain information, or responses to questions about the PRR.</li>
</ul>
<p>The Law School, like any organization engaged in complex activity in which many individuals are involved, has a body of rules to define the relationships within the organization and to implement its institutional objectives. The most important and useful of these rules are found in this handbook. Included are the rules governing the course of instruction, the Honor Code, and the constitutions of the Student Bar Association and the [I told you patience is sweet. Flag: xcx123 scholarly journals.

Please remember that these rules were established not only to help the school carry out its responsibilities as an educational institution, but also to inform everyone who is subject to them of his or her individual rights, and to guarantee that the benefits and burdens of membership in the Law School community will be shared fairly and even-handedly by all.

To function effectively the rules must be well understood, respected, and impartially enforced, with as few exceptions as possible. This handbook should be consulted in all cases where a question of compliance or infraction may arise. If necessary, an interpretation from the Office of the Dean should be secured. In most cases, the Dean of Students or the Registrar will be able to assist you.</p>
    <!-- <script type="text/javascript" src="scripts/script11.js"></script> -->

<center>
  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check11.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="xcx123")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>


</font>
</body>
</html>
