<!DOCTYPE html>
<html>
<?php

session_start();
include("connect1.php");

$sql_cnt1 = "Select cnt1 FROM points where Username='$_SESSION[Username]'";
$sql_data = mysqli_query($con,$sql_cnt1) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $cnt1=$row['cnt1'];
}


$sql_time = "Select Current_time1 FROM points where Username='$_SESSION[Username]'";
$sql_data1 = mysqli_query($con,$sql_time) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data1,MYSQLI_ASSOC)) {
   $time=$row['Current_time1'];
}



if($cnt1 == 0 && $_POST['flag']=="CX123"){
$sql ="UPDATE points SET cnt1 = cnt1+1 where Username='$_SESSION[Username]'";
$sql1 ="UPDATE points SET Current_time1=(SELECT NOW()) where Username='$_SESSION[Username]'";

if(!mysqli_query($con,$sql)){
  echo "Not Inserted";
  echo($_POST['flag']);
}
else{
  echo "Succesfully Inserted cnt1";

}


if(!mysqli_query($con,$sql1)){
  echo "Not Inserted";
  // echo($_POST['flag']);
}
else{
  echo "Succesfully Inserted time";

}



$URL="insert2.php";
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}
else{
  echo "Already Submitted";
  echo $_POST['flag'];
  $URL="index1.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
  echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

}






?>
</html>
