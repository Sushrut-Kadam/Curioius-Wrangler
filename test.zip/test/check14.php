<!DOCTYPE html>
<html>
<?php

session_start();
include("connect1.php");

$sql_cnt14 = "Select cnt14 FROM points where Username='$_SESSION[Username]'";
$sql_data = mysqli_query($con,$sql_cnt14) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $cnt14=$row['cnt14'];
}





if($cnt14 == 0){
$sql ="UPDATE points SET cnt14 = cnt14+1 where Username='$_SESSION[Username]'";
$sql1 ="UPDATE points SET Current_time1=(SELECT NOW()) where Username='$_SESSION[Username]'";

if(!mysqli_query($con,$sql)){
  echo "Not Inserted";
}
else{
  echo "Succesfully Inserted cnt14";
}


if(!mysqli_query($con,$sql1)){
  echo "Not Inserted";
}
else{
  echo "Succesfully Inserted time";

}

$URL="insert3.php";
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}
else{
  echo "Already Submitted";
  $URL="index1.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
  echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

}





?>
</html>
