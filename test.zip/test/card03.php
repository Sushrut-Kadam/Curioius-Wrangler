<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>
<title>METASTORM</title>
<head>
<link rel="stylesheet" href="Styling.css">
</head>


<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
  </script>

<font color="white">
<body id="banner_image3">


  <h1><center>Decrypt Me!</center></h1>
<center>
      <h3>Description: </h3>

            <h4>Laura Sent name of a chemical that she wants to buy from the chemical store to her friend Alex, She Sent Ciphered text to Alex as "KPTLAOFSRLAVUL"
with the shift of 7. Alex has no knowledge of Shift or ceaser cipher, but do you? Help Alex decrypting the name of the chemical.</h4>
<h4>Hint:</h4>
<h4>You need to shift up your level of understanding to survive in this round.</h4>
        </div>

  <script type="text/javascript" src="scripts/script3.js"></script>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check3.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="DIMETHYLKETONE")
    {
      cnt1+=1;
      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>


  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
</center>


</script>
</font>
</body>
</html>
