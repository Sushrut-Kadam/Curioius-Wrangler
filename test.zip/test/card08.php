<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}

a{
  color: white;
}
</style>

<title>METASTORM</title>

<head>
<link rel="stylesheet" href="Styling.css">
</head>


<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>



<font color="white">
<body id="banner_image10">

  <h1><center>CICADA3301</center></h1>

  <center><h3>Hey someone gave me a text. I think its some kind of ENCRYPTED text can you Decrypt it. The text is <h2>Hey Wrangler <strong>;)</strong> I am in a Deep Trouble i was given a ENCRYPTED text which is "PBJIXKJIKNRX" </h2></h3>
          <h3>Decrypt the text to find the flag.</h3>


          <a href="cicada3301_1.php">link 1</a>


    <!-- <script type="text/javascript" src="scripts/script8.js"></script> -->


    <script>
      function check()
      {
      var x=document.forms["myform"]["flag"].value;

      if (x=="MASTERSTROKE")
      {

        return true;
      }
      else
      {
        alert('Invalid Flag: '+x);
        return false;
      }
      }
      </script>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check8.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


<body>
</font>
</html>
