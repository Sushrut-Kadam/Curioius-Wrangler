<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>

<font color="white">
<body id="banner_image15">

  <h1><center>Who am I?</center></h1>
    <center><h3><strong>Hint :</strong></h3></center>

  <center><h3>Little 'bout my age: far from that of B<br>
   Yet in my syntax, you will find some C<br>
   The way I treat variable, that is much like D<br>
   I do take objects, but I'm not like E<br>
   If it starts with F, you'll know it's not me<br>
   Now I challenge you, just what could I be  </h3>
    <!-- <script type="text/javascript" src="scripts/script18.js"></script> -->

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check18.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="C#")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>



</font>
</body>
</html>
