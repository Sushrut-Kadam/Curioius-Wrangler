<!DOCTYPE>
<html oncontextmenu="return false">
<head>
<style > #homelink{margin: 10px;}

</style>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
  </script>
<!-- <link rel="stylesheet" href="Styling.css"> -->
</head>

<font color="black">
<body id="banner_image5">

  <h1><center>DebugIT!</center></h1>

  <center><h3>The problem statement for the following code is unclear understand the program and find the output<br>Output is your flag</h3>
  <h3>
    #include<iostream><br>
    using namespace std;<br>

    int main(){<br>
    	int real,a;<br>

    	for(int temp=1temp<=5000;temp++){<br>

    	int temp1=temp;<br>
    	int temp2=temp;<br>


    	int num=temp;<br>
    	while(num>0){<br>
    		 int d=num%10;<br>


    		num=num/10;<br>
    		int	c=num%10;<br>
    		num=num/10;<br>

    		int b num%10;<br>
    		num=num/10;<br>

    		int a=num%10;<br>
    		num=num/10;<br>


    		temp1=temp1/10;<br>
    		temp1 temp1/10;<br>
    		int ab=temp1;<br>

    	   temp2=temp2%100;<br>
    		int cd=temp2;<br>



    		if(d==2*a){<br>
    			if(b==c){<br>
    				if(cd ==; 2*ab){<br>
    					real=temp;<br>

    				}<br>
    			}<br>
    		}<br>



    	}<br>
    }<br>
    	cout<<"Number is: "<<real;<br>
    }<br>


  </h3>

  <!-- <script type="text/javascript" src="scripts/script4.js"></script> -->


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x==4998)
    {
      cnt1+=1;
      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check4.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>

  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
</center>


<font>
</body>
</html>
