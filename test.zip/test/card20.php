<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>


<font color="white">
<body id="banner_image20">


  <h1><center>Curious Waiter</center></h1>

  <center><h3>Siddharth is a waiter at a local deli, he has to wash 15 dishes (kept one on top of other) each with a number on it.<br><br>
Stack->{5,7,14,15,21,24,25,36,44,49,50,56,64,85 ,91}<br><br>
Before washing the dishes, he segregates them in three categories and keeps them (one on top of other)<br><br>
Category 1: Number on plate is divisible by 4.<br>
Category 2: Number on plate is divisible by 5.<br>
Category 3: Number on plate is divisible by 7.<br><br>

1) Siddharth washes 1 plate from category 3<br>
2) Siddharth washes 2 plates from category 2<br>
3) Siddharth washes 3 plates from category 1<br><br>

What will be the number on the plate that he will wash if he chooses to wash a plate from category 2
<br>
</h3>
    <script type="text/javascript" src="scripts/script20.js"></script>

  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check20.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x==25)
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>

</font>
</body>
</html>
