<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
session_start();
include("connect1.php");

?>
<p><?php echo $_SESSION['Username']; ?></p>
<?php
$sql_points = "Select total_points FROM points where Username='$_SESSION[Username]'";
$sql_data = mysqli_query($con,$sql_points) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $points=$row['total_points'];
}



?>

<style>
.topright span{
  display: inline-block;
  position: absolute;
  top: 8px;
  right: 16px;
  font-size: 18px;
}
</style>




<p class="topright">
  <span><font color="white"><?php echo"Points: $points" ?></span></font>
</p>

<style>
* {
  box-sizing: border-box;
}


body{
  background-color:#ff9933;
 /* background-image: url("back1.jpg"); */

}




body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 15%;
  padding: 0px 17px;
  margin: 20px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;

}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {

  box-shadow: 0 4px 8px 0 rgba(1.0, 1.5, 1.5, 2.0);
  padding: 25px;
  text-align: center;
  background-color: #ffffb3;
  /* background-image: url("gg.jpg"); */
}


</style>
</head>
<body>



<h2><center> <font color="white">Curious Wrangler</center></h2></font>
<p><font color="white">Capture the flag to win.</p></font>

<div class="row">
  <div class="column">
    <div class="card">
      <h3>What's the Source?</h3>
      <p>Where to find </p>
      <a href='testcard01.php'><button>Go to question.</button></a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>Leaf of Tree</h3>
      <p>Data Structure Maybe?</p>
      <a href='card02.php'><button>Go to question.</button></a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>Decrypt Me!</h3>
      <p>how good is your Cryptography?</p>
    <a href='card03.php'><button>Go to question.</button></a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>ConVersion</h3>
      <p>Convert Some Digits, Pretty Simple!</p>
        <a href='card04.php'><button>Go to question.</button></a>
    </div>
  </div>



      <div class="column">
        <div class="card">
          <h3>DebugIT!</h3>
          <p>Find the error,Run it </p>
        <p>Simple, Right?</p>
        <a href='card05.php'><button>Go to question</button></a>

        </div>
      </div>

</div>

<div class="row">

      <div class="column">
        <div class="card">
          <h3>Subnet Attack</h3>
          <p>Find your Subnet</p>
          <a href='card06.php'><button>Go to question</button></a>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Time is Running!</h3>
          <p>Generate a Random String</p>
         <a href='card07.php'><button>Go to question</button></a>
        </div>
      </div>


      <div class="column">
        <div class="card">
          <h3>Decrypt ME 2!</h3>
          <p>You've done it before!! </p>
          <a href='card08.php'><button>Go to question</button></a>
        </div>
      </div>


      <div class="column">
        <div class="card">
          <h3>Solve the Error!</h3>
          <p>Solve the Error to capture the flag!</p>
          <a href='card09.php'><button>Go to Question</button></a>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>DebuIT 2!</h3>
          <p>Pattern Generation</p>
          <a href='card10.php'><button>go to question</button></a>
        </div>
      </div>
</div>

<div class="row">

      <div class="column">
        <div class="card">
          <h3>Social Media</h3>
          <p>Debug the code and the output will give you a hint.</p>
          <button>Go to question</button>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Tocced! </h3>
          <p>Generate the String from the statement.</p>
          <button>go to qustion</button>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Power Up!!</h3>
          <p>Simple Maths thats all!</p>
          <button>Go to question</button>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Go for the Head!</h3>
          <p>Power is within me!!!</p>
          <button>Go to question</button>
        </div>
      </div>



      <div class="column">
        <div class="card">
          <h3>Weird Combination</h3>
          <p>Find the Perfect Combination to catch the flag!</p>
          <button>Go to question</button>
        </div>
      </div>

</div>

<div class="row">
      <div class="column">
        <div class="card">
          <h3>Split the Number</h3>
          <p>Split the Number</p>
          <button>Go to question</button>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 17</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>


      <div class="column">
        <div class="card">
          <h3>Card 18</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>


      <div class="column">
        <div class="card">
          <h3>Card 19</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 20</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

</div>

<div class="row">

      <div class="column">
        <div class="card">
          <h3>Card 21</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 22</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 23</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 24</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 25</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>
</div>
      <div class="column">
        <div class="card">
          <h3>Card 26</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 27</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 28</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 29</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>

      <div class="column">
        <div class="card">
          <h3>Card 30</h3>
          <p>Some text</p>
          <p>Some text</p>
        </div>
      </div>


</div>

</body>
</head>
</html>
