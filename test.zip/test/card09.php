<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
  <!-- <link rel="stylesheet" href="Styling.css"> -->
</head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }

</script>



<h1><center>Go For the Head!</center></h1>

  <title>METASTORM</title>

       <!-- Latest compiled and minified CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

       <!-- jQuery library -->
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

       <!-- Latest compiled and minified JavaScript -->
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

       <!-- <link rel="stylesheet" href="Styling.css"> -->

       <style>
           h3,h5{
               color: black;
           }
           p{
               color: black;
               font-size: 22px;
           }

           .panel{
               margin-top: 50px;
               alignment-adjust: middle;
           }
       </style>
</head>
<font color="black">
<body id="banner_image9">


   <div class="container">
       <div id="banner_content" class="row inner-banner-image">
           <center><h3><strong>Description:</strong></h3></center>
           <center><p>Mathematics develops the foundation for everything</p></center>
       </div>

       <div class="row">
           <img src="Media/Go_for_the_head.png">
       </div>

   </div>

<center>
  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check9.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x==12345)
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>

</font>
</body>
</html>
