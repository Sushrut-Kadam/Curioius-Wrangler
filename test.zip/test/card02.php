<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>
<head>

<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>
<link rel="stylesheet" href="Styling.css">
</head>

<font color="white">
<body id="banner_image13">

<div id="banner_content" class="row inner-banner-image">
  <h1><center>HEXimus</center></h1>
  <center>
  <h2>Description:</h2>
  <h3>This is year 2095, robots are common now. Ravi is the teacher in the school for robots.HEXimus are
programmable robot student had a doubt in the last lecture.Ravi had given a sequence of input
numbers, but HEXimus’s input system could not fetch the last number. Find the last number from
the sequence and write it in a form that HEXimus will understand and that is your flag.</h3>
  <h3>What will be the next number 5,10,19,32,49,70 ….?</h3>
  <h3>Hint: It's Not what you think! Do some Conversion before....</h3>
</div>

<center>
  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check2.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
<script>
  function check()
  {
  var x=document.forms["myform"]["flag"].value;

  if (x=="0X5F")
  {
    cnt1+=1;
    return true;
  }
  else
  {
    alert('Invalid Flag: '+x);
    return false;
  }
  }
  </script>

  <div>
    <div>  </div>

  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
</center>

</body>
</font>
</html>
