<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>


<title>METASTORM</title>
<font color="white">
<h1><center>Dustbin </center></h1>
</font>
<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>

  <title>METASTORM</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="Styling.css">

        <style>
            h3,h5{
                color: white;
            }
            p{
                color: white;
                font-size: 22px;
            }

            .panel{
                margin-top: 50px;
                alignment-adjust: middle;
            }
        </style>
</head>
<!-- <font color="white"> -->
<body id='banner_image17'>
    <div class="container">
        <div id="banner_content" class="row inner-banner-image">
            <center><p><strong>Description:</strong></p></center>
            <center><p>Long lines of code make you worried, but have you ever thought of the hidden meaning in it</p></center>

            <center><p><strong>Hint: </strong></p></center>
            <center><p>Syntax and Semantics go hand in hand.</p><p>Look around for a programming code !</p></center>
        </div>


    </div>
    <center>
  <p>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check10.php" >
     <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="Code4358")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>

</font>
</body>
</html>
