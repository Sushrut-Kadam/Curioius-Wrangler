<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>


<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>


<font color="white">
<body id="banner_image23">

  <h1><center>RETROGRESSION</center></h1>

  <body>
  <div class="container">
        <div id="banner_content" class="row inner-banner-image">
            <center><h3><strong>Description:</strong></h3></center>
            <center><p>A lazy person finds the easiest way to do a task.</p></center>

            <center><h3><strong>Hint:</strong></h3></center>
            <center><p>galf = NIAGAOGEWEREHTIHSHA</p></center>
        </div>

  </div>
</body>
<center>
  <h3>Enter Flag</p>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check17.php" >
    Flag: <input type="text" name="flag" autocomplete="off">
          <input type="submit" >
  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>

  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="AHSHITHEREWEGOAGAIN")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>


</font>
</body>
</html>
