<!DOCTYPE html>
<html>
<head>
        <title>METASTORM</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="Styling.css">
</head>


<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
session_start();
include("connect1.php");

?>
<font color="white"><h4><p><?php echo $_SESSION['Username']; ?></p><h4></font>
<?php
$sql_points = "Select total_points FROM points where Username='$_SESSION[Username]'";
$sql_data = mysqli_query($con,$sql_points) or die("Unable to connect");

while ($row = mysqli_fetch_array($sql_data,MYSQLI_ASSOC)) {
   $points=$row['total_points'];
}
?>

<style>
.topright span{
  display: inline-block;
  position: absolute;
  top: 8px;
  right: 16px;
  font-size: 18px;
}
</style>



<p class="topright">
  <span><font color="white"><?php echo"Points: $points" ?></span></font>
</p>

<body id="banner_image">
    <div class="container">
        <h1><strong><center><font color="white">Curious Wrangler</font></center></strong></h1>
        <h4><strong><center><font color="white">Mind your mind</font></center></strong></h4>

       <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>What's the Source?</h3>
                    <p>Where to find </p>
                    <p>Points: 20</p>
                    <a href='testcard01.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>HEXimus</h3>
                    <p>Numbers huh?</p>
                    <p>Points: 30</p>
                    <a href='card02.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Decrypt Me!</h3>
                    <p>how good is your Cryptography?</p>
                    <p>Points: 20</p>
                    <a href='card03.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>DebugIT!</h3>
                    <p> Some Digits, Pretty Simple!</p>
                    <p>Points: 10</p>
                    <a href='card04.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>
        </div>





        <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>DebugIT2!</h3>
                    <p>find the error,Run it </p>
                    <p>Simple, Right?</p>
                    <p>Points: 20</p>
                    <a href='card05.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Subnet Attack</h3>
                    <p>Find your Subnet</p>
                    <p>Points: 10</p>
                    <a href='card06.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Time is Running!</h3>
                    <p>Generate a Random String</p>
                    <p>Points: 10</p>
                    <a href='card07.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>CICADA3301!</h3>
                    <p>You've done it before!! </p>
                    <p>Points: 20</p>
                    <a href='card08.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


        </div>




        <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Go for the Head!</h3>
                    <p>Power is Within me!</p>
                    <p>Points: 30</p>
                    <a href='card09.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Dustbin</h3>
                    <p>Best out of Waste</p>
                    <p>Points: 20</p>
                    <a href='card10.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Rubbish</h3>
                    <p>Minerals are always found deep underground.</p>
                    <p>Points: 10</p>
                    <a href='card11.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Number System </h3>
                    <p>Knowledge of just one number system is not enough.</p>
                    <p>Points: 30</p>
                    <a href='card12.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


        </div>





        <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I? (1)</h3>
                    <p>Let's see how fast can you identify me.</p>
                    <p>Points: 20</p>
                    <a href='card13.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>C-ing IT</h3>
                    <p>How good are you at programming</p>
                    <p>Points: 30</p>
                    <a href='card14.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>



            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>BrainStorm</h3>
                    <p>Learn to use your Brain</p>
                    <p>Points: 40</p>
                    <a href='card15.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I? (2)</h3>
                    <p>Can you identify me?</p>
                    <p>Points: 10</p>
                    <a href='card16.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


        </div>



        <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>RETROGRESSION</h3>
                    <p>A lazy person finds the easiest way to do a task.</p>
                    <p>Points: 20</p>
                    <a href='card17.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I? (3)</h3>
                    <p>Haha You have to identify again!</p>
                    <p>Points: 40</p>
                    <a href='card18.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Figure IT</h3>
                    <p>Only 1 choice is not enough always</p>
                    <p>Points: 20</p>
                    <a  href='card19.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Curious Waiter</h3>
                    <p>At last the Final question</p>
                    <p>Points: 40</p>
                    <a href='card20.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>
        </div>




        <!-- <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Info of Data</h3>
                    <p>To search something, we need to know something about something</p>
                    <a href='card21.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Number System</h3>
                    <p>One is not sufficient</p>
                    <a href='card22.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>BrainStorm</h3>
                    <p>Learn to use your brain</p>
                    <a href='card23.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Figure IT</h3>
                    <p>Only 1 choice is not enough always</p>
                    <a  href='card24.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>
        </div>




        <div class="row-style text-center">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I ? (1)</h3>
                    <p>Let's see how fast can you identify me</p>
                    <a href='card25.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I ? (2)</h3>
                    <p>Can you identify me</p>
                    <a href='card26.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Who am I ? (3)</h3>
                    <p>Haha.. You have to identify again !</p>
                    <a href='card27.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>


            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <h3>Structures</h3>
                    <p>Shape and functionality matter the most</p>
                    <a href='card28.php' class="btn btn-primary btn-block">Go to question</a>
                </div>
            </div>

        </div>
     </div>
    </div> -->

</body>
</html>
