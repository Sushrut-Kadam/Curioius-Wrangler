<?php
include "connect1.php";
session_start();
$sql ="UPDATE points SET total_points = total_points+10 where Username='$_SESSION[Username]'";

if(!mysqli_query($con,$sql)){
  echo "Not Inserted";
}
else{
  echo "CORRECT FLAG!";
}
header("refresh:0; url=index1.php")

?>
