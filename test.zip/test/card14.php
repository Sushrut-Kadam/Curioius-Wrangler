<!DOCTYPE>
<html oncontextmenu="return false">
<style > #homelink{margin: 10px;}
</style>

<head>
<link rel="stylesheet" href="Styling.css">
</head>


<title>METASTORM</title>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>


<font color="white">
<body id="banner_image1">



  <h1><center>C-ing IT!</center></h1>
</font>
  <head>
          <title>METASTORM</title>

          <!-- Latest compiled and minified CSS -->
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

          <!-- jQuery library -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

          <!-- Latest compiled and minified JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

          <link rel="stylesheet" href="Styling.css">

          <style>
              h3,h5{
                  color: black;
              }
              h4{
                  color: white;
                  font-size: 25px;
              }

              .panel{
                  margin-top: 50px;
                  alignment-adjust: middle;
              }
          </style>
  </head>
<font color="white">
  <body id="banner_image5">
    <div class="container">
          <div id="banner_content" class="row inner-banner-image">
              <center><h4><strong>Description:</strong></h4></center>
              <center><h4>Let's see how good you are with C programming fundamentals</h4></center>

              <center><h4><strong>Note:</strong></h4></center>
              <center><h4>The Output of the follwing C program is your flag</h4></center>
          </div>

        <div class="row">
            <img src="Media/C-ing_IT.png">
        </div>

    </div>
  </body>
<center>
<font color="white">
  <h3>Enter Flag</p>
      </font>
  <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check14.php" >
     <input type="text" name="flag" autocomplete="off">
          <input type="submit" >

  </form>
  <div>
  <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
  </div>
  </center>


  <script>
    function check()
    {
    var x=document.forms["myform"]["flag"].value;

    if (x=="Focus_on_output 16")
    {

      return true;
    }
    else
    {
      alert('Invalid Flag: '+x);
      return false;
    }
    }
    </script>

</font>
</body>
</html>
