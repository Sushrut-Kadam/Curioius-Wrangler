<!DOCTYPE html>
<html oncontextmenu="return false">
<head>
<title>METASTORM</title>
<style > #homelink{margin: 20px;}

</style>

<script>
  document.onkeydown = function(e) {
  if(event.keyCode == 123) {
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
  return false;
  }
  if(e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)){
  return false;
  }
  }
</script>
<link rel="stylesheet" href="Styling.css">
</head>

<font color="white">
<body id="banner_image2">
  <div id="banner_content" class="row inner-banner-image">

  <h1><center>What's the Source?</center></h1>

<center>
  <h3>Description: Some one gave me a webpage, the link is given below Cannot figure out where exactly is the flag? Help me find it </h3>
  <a href="whatsthesource.php">This is the link</a>
  <h3>Hint: </h3>
    <h3>Where do you find the content of the webpage?<h3>
      <h3>How do you Inspect it??<h3>

</center>

</div>


  <!-- <script type="text/javascript" src="scripts/script1.js"></script> -->

      <center>
      <h3>Enter Flag</h3>
      <form method="post"  onsubmit="return check();" id="myform" name="myform" action="check1.php" >
        Flag: <input type="text" name="flag" autocomplete="off">
              <input type="submit" >
      </form>


      <script>
        function check()
        {
        var x=document.forms["myform"]["flag"].value;

        if (x=="CX123")
        {
          cnt1+=1;
          return true;
        }
        else
        {
          alert('Invalid Flag: '+x);
          return false;
        }
        }
        </script>

      <a href="index1.php"><button id="homelink">Go To Homepage</button></a>
      </div>
    </center>









</body>
</font>
</html>
